package ${packageName}.contract;
import library.base.IBasePresenter;
import library.base.IBaseView;
/**
 * ${customName} V
 */
public interface ${customName}Contract {
    interface View extends IBaseView {

    }

    interface Presenter extends IBasePresenter {

    }
}
