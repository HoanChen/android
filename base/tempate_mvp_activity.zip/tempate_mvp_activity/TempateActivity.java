package ${packageName}.ui;
import library.base.BaseMvpActivity;
/**
 * ${customName} V
 */
public class ${customName}Activity extends BaseMvpActivity<${customName}Contract.Presenter> implements ${customName}Contract.View {
    @Override
    protected int getInnerViewId() {return R.layout.activity_${layoutName};}
	
	@NotNull
    @Override
    protected ${customName}Contract.Presenter createPresenter() {return new ${customName}Presenter(this);}

}
