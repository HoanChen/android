把这个文件夹复制到 AndroidStudio模版的存放路径（注意是复制整个文件夹）!

Windows : AndroidStudio安装目录\plugins\android\lib\templates/用户
	例如：D:\Program Files\Android\Android Studio\plugins\android\lib\templates\zhaoyuehai


Mac : /Applications/Android Studio.app/Contents/plugins/android/lib/templates/用户